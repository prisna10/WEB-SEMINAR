# Seminar Nasional Sistem Informasi

Project PHP OOP untuk tugas Pertemuan 9.

## Struktur OOP

- `public/index.php` berperan sebagai perakit: memuat class, membuat object seminar dan produk, menjalankan demo setter, lalu memanggil view.
- `app/Product.php` menyimpan model produk dengan property private, constructor, getter, dan setter.
- `app/Seminar.php` menyimpan kumpulan object `Product` dan method kalkulasi total.
- `views/ringkasan.php` berisi template HTML dan `foreach` untuk menampilkan data object.
- `assets/` berisi Bootstrap dan JavaScript interaksi halaman.

Data seminar masih hardcoded sesuai ketentuan tugas dan belum menggunakan database.
