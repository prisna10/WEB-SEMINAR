<?php
require 'config.php';

session_set_cookie_params(SESSION_TIMEOUT_SECONDS, "/");
session_start();
// Menghapus semua sesi login
$_SESSION = [];
if (ini_get("session.use_cookies")) {
    $params = session_get_cookie_params();
    setcookie(session_name(), '', time() - 42000, $params["path"], $params["domain"], $params["secure"], $params["httponly"]);
}
session_destroy();
// Mengarahkan kembali ke halaman utama
header("Location: index.html");
exit();
?>